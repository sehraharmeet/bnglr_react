// Counter.tsx
import React, { useState } from 'react';

const MyCounter: React.FC = () => {
  const [count, setCount] = useState<number>(10);

  return (
    <div>
      <h1 data-testid="count">{count}</h1>
      <button onClick={() => setCount(count + 1)}>Increment</button>
    </div>
  );
};

export default MyCounter;