import React, { useEffect, useState } from "react";

type ApiResponse = {
  message: string;
  status: string;
};

const HarmeetAPI = () => {
  const [data, setData] = useState<ApiResponse | null>(null);

  useEffect(() => {
    fetch("http://127.0.0.1:5000/harmeet")
      .then((res) => res.json())
      .then((result: ApiResponse) => {
        setData(result);
      })
      .catch((err) => console.error("Error:", err));
  }, []);

  return (
    <div>
      <h2>Flask API Data</h2>
      {data ? (
        <>
          <p><strong>Message:</strong> {data.message}</p>
          <p><strong>Status:</strong> {data.status}</p>
        </>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default HarmeetAPI;