//MyCoutner.test.tsx
import { render, screen } from '@testing-library/react';
import MyCounter from './MyCounter';
import { fireEvent } from '@testing-library/react';

test('renders initial count', () => {
  render(<MyCounter />);
  const countElement = screen.getByTestId('count');
  console.log('VALUE:', countElement.textContent);  
  expect(countElement.textContent).toBe('10');  
});



test('increments count on button click', () => {
  render(<MyCounter />);
  
  const button = screen.getByText('Increment');
  fireEvent.click(button);

  const countElement = screen.getByTestId('count');

  expect(countElement.textContent).toBe('11');
});

test('button exists with correct label', () => {
  render(<MyCounter />);
  const button = screen.getByRole('button', { name: /Increment/i });
  expect(button).toBeInTheDocument();
});