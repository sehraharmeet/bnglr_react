import React from 'react';
import logo from './logo.svg';
import './App.css';
import MyCounter from './MyCounter';
import HarmeetAPI from './newcomp';

function App() {
  return (
    <div className="App">
      {/* <MyCounter /> */}
      <HarmeetAPI />
    </div>
  );
}

export default App;
