describe('MyCounter E2E Test', () => {

  // 🔹 Runs before each test
  beforeEach(() => {
    cy.visit('http://localhost:3000');
  });

  it('should display initial count as 10', () => {
    cy.get('[data-testid="count"]').should('have.text', '10');
  });

  it('should have an Increment button', () => {
    cy.contains('button', 'Increment').should('be.visible');
  });

  it('should increment count on button click', () => {
    cy.contains('Increment').click();
    cy.get('[data-testid="count"]').should('have.text', '11');
  });

  it('should increment count multiple times', () => {
    cy.contains('Increment').click().click().click();
    cy.get('[data-testid="count"]').should('have.text', '13');
  });

  it('should not show incorrect value', () => {
    cy.get('[data-testid="count"]').should('not.have.text', '999');
  });

});