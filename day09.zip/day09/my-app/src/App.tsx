import React from 'react';
import logo from './logo.svg';
import './App.css';
import MyCounter from './MyCounter';
import MyCounter2 from './MyCounter2';

function App() {
  return (
    <div className="App">
      <MyCounter />
      <MyCounter2 />
    </div>
  );
}

export default App;
