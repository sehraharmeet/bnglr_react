// MyCounter.tsx
import React, { useState } from 'react';

const MyCounter2: React.FC = () => {
  const [count, setCount] = useState<number>(10);

  const handleIncrement=()=>{
     
        setCount(count+1);
    
  }
  const handleDecrement=()=>{
     if(count>0)
        setCount(count-1);
    
  }
  return (
    <div>
      <h1 data-testid="count">{count}</h1>
      <button onClick={handleIncrement}>Increments</button>
      <button onClick={handleDecrement} disabled={count<=0}>Decrement</button>
    </div>
  );
};

export default MyCounter2;