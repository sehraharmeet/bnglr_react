//MyCoutner.test.tsx
import { render, screen } from '@testing-library/react';
import MyCounter from './MyCounter';
import { fireEvent } from '@testing-library/react';
import exp from 'constants';


describe("My New Component Testing Business",()=>{

// //we are checcking the count values
// test('renders initial count', () => {
//   render(<MyCounter />);
//   const countElement = screen.getByTestId('count');
//   console.log('VALUE:', countElement.textContent);  
//   expect(countElement.textContent).toBe('10');  
// });

// // we are checking when someone click on button its inccremented properly
// test('increments count on button click', () => {
//   render(<MyCounter />);
//   const button = screen.getByText('Increment');
//   fireEvent.click(button);
//   const countElement = screen.getByTestId('count');
//   expect(countElement.textContent).toBe('11');
// });

// //do we have button with specific text
// test('button exists with correct label', () => {
//   render(<MyCounter />);
//   const button = screen.getByRole('button', { name: /Increment/i });
//   expect(button).toBeInTheDocument();
// });

// test('increments count on button click', () => {
//   render(<MyCounter />);
//   const button = screen.getByText('Increment');
//   fireEvent.click(button);
//   fireEvent.click(button);
//   fireEvent.click(button);  
//   fireEvent.click(button);
//   const countElement = screen.getByTestId('count');
//   expect(countElement.textContent).toBe('14');
// });
// test('decrement button should be checked',()=>{
//     render(<MyCounter />);
//     fireEvent.click(screen.getByText('Decrement'));
//     expect(screen.getByTestId('count').textContent).toBe('9');
// });
// test('should not decrement below 0',()=>{
//     render(<MyCounter />);
//     const decBtn=screen.getByText('Decrement');
//     for(let i=0;i<20;i++)
//     {
//         fireEvent.click(decBtn);
//     }
//      const countElement = screen.getByTestId('count');
//      expect(countElement.textContent).toBe('0');
// });
test('should be diabled at  0',()=>{
    render(<MyCounter />);
    const decBtn=screen.getByText('Decrement');
    for(let i=0;i<50;i++)
    {
        fireEvent.click(decBtn);
    }
    //const countElement = screen.getByTestId('count');
    // expect(countElement.textContent).toBe('0');
    expect(decBtn).toBeDisabled();
});
});