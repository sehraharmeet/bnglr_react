describe('MyCounter E2E Test', () => {

  // 🔹 Runs before each test
  beforeEach(() => {
    cy.visit('http://localhost:3000');
  });

  it('should display initial count as 10', () => {
    cy.get('[data-testid="count"]').should('have.text', '10');
  });

});