// // MyContext.tsx
// import { createContext } from "react";

// export interface MyContextType {
//   text: string;
// }

// // Create context with default values
// export const MyContext = createContext<MyContextType>({
//   text: ""
// });

import { createContext } from "react";

export interface MyContextType {
  text: string;
  setText: (value: string) => void;
}

export const MyContext = createContext<MyContextType>({
  text: "",
  setText: () => {},
});
