import React, { useState } from "react";
import logo from './logo.svg';
import './App.css';
import Hello from './Hello';
import Hello1 from './Hello1';
import NewsCard from './News';
import Day03_2 from './Day03_2';
import D3_01 from './D3_01';
import D3_02 from './D3_02';
import D3_01_1 from './D3_01_1';
import D3_03 from './D3_03';
import D3_04 from './D3_04';
import { MyContext } from './MyContext';
import MyComponent from './MyComponent';
import MyComponent2 from "./MyComponent2";
import ThemeComp from "./ThemeComp";
import { ThemeProvider } from "./ThemeContext";
 
// function App() { 
//   const company: string = "Bosch, Bangalore";
//   const [text] = useState<string>("Harmeet From Main App");
//   return (
//     <div className="App">
//       <div>
//       <MyContext.Provider value={{ text}}>
//         <MyComponent />
//       </MyContext.Provider>
//          </div>
//     </div>
//   );
// }

function App() {
  const [text, setText] = useState<string>("Harmeet From Main App");

  return (
    <div className="App">
      {/* <MyContext.Provider value={{ text, setText }}>
        <MyComponent />
        <MyComponent2 />
      </MyContext.Provider> */}
      <ThemeProvider>
      <ThemeComp />
    </ThemeProvider>
    </div>
  );
}


export default App;
