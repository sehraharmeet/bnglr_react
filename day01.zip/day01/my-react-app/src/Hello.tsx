// import React from 'react';
// ////interface typing
// interface HelloProps
// {
//     name:string;
//     company:string;
//     country?:string;//now its optional
// }

//  const Hello: React.FC<HelloProps> = (props) => {
// ////Inline Typing
// //  const Hello=(props:{name:string;company:string;country:string})=> {
//   return (
//     <div>
//       <h1>Hello to New World of Web Programming</h1>
//       <h1>Hello{props.name}</h1>
//       <h2>{props.company}</h2>
//       <h2>{props.company === "Bosch, Bangalore" ? "Welcome to Bosch" : "Keep Trying"}</h2>
//       <h2>{props.country}</h2>
//     </div>
//   );
// };

// export default Hello;

// import React, { Component } from 'react';

// interface HelloProps {
//   name: string;
//   company: string;
// }

// class Hello extends Component<HelloProps> {
//   render() {
//     return (
//       <div>
//         <h1>Hello {this.props.name}</h1>
//         <h2>{this.props.company}</h2>
//       </div>
//     );
//   }
// }

// export default Hello;

import React, { Component } from 'react';

interface HelloProps {
  name: string;
  company: string;
}

class Hello extends Component<HelloProps> {

  componentDidMount() {
    console.log("Component Mounted (Loaded)");
  }

  componentDidUpdate(prevProps: HelloProps) {
    if (prevProps.name !== this.props.name) {
      console.log("Component Updated (Name Changed)");
    }
  }

  componentWillUnmount() {
    console.log("Component Will Unmount (Removed)");
  }

  render() {
    return (
      <div>
        <h1>Hello {this.props.name}</h1>
        <h2>{this.props.company}</h2>
        
      </div>
    );
  }
}

export default Hello;

