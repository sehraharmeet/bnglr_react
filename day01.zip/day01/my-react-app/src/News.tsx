import React, { Component } from 'react';

interface NewsProps {
  title: string;
  category: string;
  isBreaking?: boolean; // optional
}

class NewsCard extends Component<NewsProps> {
  render() {
    const { title, category, isBreaking } = this.props;//desctructring

    return (
      <div style={{
        border: "1px solid #ccc",
        padding: "15px",
        margin: "10px",
         width: "300px"
      }}>
        
        {isBreaking && <h3 style={{ color: "red" }}>Breaking News</h3>}

        <h2>{title}</h2>
        <h4>Category: {category}</h4>

        <p>
          {category == "Technology" ? "Trending in Tech" : "Latest Update"}
        </p>

      </div>
    );
  }
}

export default NewsCard;