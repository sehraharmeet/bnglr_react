import React, { useState, useEffect } from 'react';
const D3_03 = () => {
  const [count, setCount] = useState(0);
    const [name, setChangeN] = useState("Harmeet");
////1. complete page tracking
//   useEffect(() => {
//     console.log("Count updated:", count);
//   });
////2. only one time trigger
// useEffect(() => {
//     console.log("Count updated:", count);
//   },[]);
////3. trigger will be done ONLY for count variable 
useEffect(() => {
    console.log("Count updated:", count);
  },[count]);
useEffect(() => {
    console.log("Hey This is Name Touch Base");
  },[name]);
  const increment = () => {
    setCount(count + 1);
  };
   const changeMyName = () => {
    setChangeN(name=="Harmeet"?"Reema":"Harmeet");
  };
  return (
    <div>
      <h1>Counter: {count}</h1>
      <h1>Name: {name}</h1>
      <button onClick={increment}>Increase</button>
     <button onClick={changeMyName}>Change Name</button>

    </div>
  );
};
export default D3_03;
