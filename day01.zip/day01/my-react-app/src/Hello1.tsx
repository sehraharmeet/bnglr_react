import React from 'react';

const Hello1=()=>{
    return <div>
                <h1>Hello to New World of WEb Programming</h1>
                <h1>Harmeet</h1>
            </div>;

};

export default Hello1;
