// // MyComponent.tsx
// import React, { useContext } from "react";
// import { MyContext } from "./MyContext";

// const MyComponent: React.FC = () => {
//   const { text} = useContext(MyContext);

//   return (
//     <div>
//       <h1>{text}</h1>
      
//     </div>
//   );
// };

// export default MyComponent;

// MyComponent.tsx
import React, { useContext } from "react";
import { MyContext } from "./MyContext";

const MyComponent: React.FC = () => {
  const { text, setText } = useContext(MyContext);
const callme=() => setText("Updated from Child");
  return (
    <div>
      <h1>{text}</h1>

      <button onClick={callme}>
        Change Text
      </button>
    </div>
  );
};

export default MyComponent;
