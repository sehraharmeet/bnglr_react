
import React, { Component } from 'react';

interface HelloProps {
  name: string;
  company: string;
}

class Hello extends Component<HelloProps> {
 
  render() {
    return (
      <div>
        <h1>Hello {this.props.name}</h1>
        <h2>{this.props.company}</h2>
        
      </div>
    );
  }
}

export default Hello;
