 
import React, { useEffect, useState } from 'react';

const D3_04 = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

 useEffect(()=>{
  fetch('https://jsonplaceholder.typicode.com/users')
    .then(response => response.json())
    .then(data => {
      console.log("API called");
      setUsers(data);
      setLoading(false);
    })
    .catch(error => {
      console.log("Error:", error);
      setLoading(false);
    });
},[]);
  return (
    <div>
      <h1>User List (Wrong Way)</h1>

      {loading ? (
        <h3>Loading...</h3>
      ) : (
        users.map((user) => (
          <div key={user.id}>
            <h2>{user.name}</h2>
            <p>{user.email}</p>
          </div>
        ))
      )}
    </div>
  );
};

export default D3_04;
