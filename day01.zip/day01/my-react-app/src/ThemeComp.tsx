import React, { useContext } from "react";
import { ThemeContext } from "./ThemeContext";

const ThemeComp: React.FC = () => {
  const context = useContext(ThemeContext);

  if (!context) {
    throw new Error("ThemeContext must be used within ThemeProvider");
  }

  const { theme, toggleTheme } = context;

  return (
    <div>
      <h1>Current Theme: {theme}</h1>
      <button onClick={toggleTheme}>Toggle Theme</button>
    </div>
  );
};

export default ThemeComp;