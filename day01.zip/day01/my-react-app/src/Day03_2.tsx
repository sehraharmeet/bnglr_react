import React, { useState, useEffect } from 'react';

const Day03_2 = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => response.json())
      .then(data => {
        setUsers(data);
        setLoading(false);
      })
      .catch(error => {
        console.log("Error fetching data:", error);
        setLoading(false);
      });
  }, []);

  return (
    <div>
      <h1>User List</h1>

      {loading ? (
        <h3>Loading...</h3>
      ) : (
        users.map((user) => (
          <div key={user.id}>
            <h2>{user.name}</h2>
            <p>{user.email}</p>
          </div>
        ))
      )}
    </div>
  );
};

export default Day03_2;
