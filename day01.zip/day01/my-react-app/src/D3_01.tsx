//D3_01.tsx
import React, { Component } from 'react';

class D3_01 extends Component {
 state = {
  count: 100,
  name:"Harmeet"
 };

 increment = () => {
  this.setState({ count: this.state.count + 2 });
 };
 decrement = () => {
  this.setState({ count: this.state.count - 2 });
 }; 
 reset = () => {
  this.setState({ count: 100 });
 };
 changeMyName = () => {
  this.setState({ name: this.state.name=="Harmeet"?"Reema":"Harmeet"});
 };
 render() {
  return (
   <div>
    <h1>Counter: {this.state.count}</h1>
    <h1>Name: {this.state.name}</h1>
    <button onClick={this.increment}>Increase</button>
    <button onClick={this.decrement}>Decrease</button>
    <button onClick={this.reset}>Reset</button>
        <button onClick={this.changeMyName}>Change Name</button>

   </div>
  );
 }
}

export default D3_01;

