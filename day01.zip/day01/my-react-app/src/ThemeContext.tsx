// src/ThemeContext.tsx
import React, { createContext, useState, ReactNode } from "react";

// 1. Define Theme Type (restrict values)
type Theme = "light" | "dark";

// 2. Define Context Type
interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

// 3. Create Context
export const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// 4. Define Props Type for Provider
interface ThemeProviderProps {
  children: ReactNode;
}

// 5. Create Provider Component
export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>("light");

  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === "light" ? "dark" : "light"));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};