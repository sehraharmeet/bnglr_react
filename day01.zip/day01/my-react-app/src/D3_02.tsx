//D3_02.tsx
import React, { useState,useEffect } from 'react';

const D3_02 = () => {
  const [count, setChange] = useState(0);
  const [name, setChangeN] = useState("Harmeet");
 useEffect(() => {
    console.log("welcome");
  });
  const increment = () => {
    setChange(count + 1);
  };
  const decrement = () => {
    setChange(count - 1);
  }; 
  const reset = () => {
    setChange(0);
  };
  const changeMyName = () => {
    setChangeN(name=="Harmeet"?"Reema":"Harmeet");
  };

  return (
    <div>
      <h1>Counter: {count}</h1>
      <h1>Name: {name}</h1>
      <button onClick={increment}>Increase</button>
      <button onClick={decrement}>Decrease</button>
      <button onClick={reset}>Reset</button>
      <button onClick={changeMyName}>Change Name</button>
    </div>
  );
};

export default D3_02;
