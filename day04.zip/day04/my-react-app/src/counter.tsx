import React, { useReducer } from 'react';
//1. state definition
type State = {
  count: number;
};
//2. action definition
type Action =
  | { type: 'increment' }
  | { type: 'decrement' }
  | { type: 'reset' };

//3. initial state
const initialState: State = { count: 0 };

//4. reducer function
const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case 'increment':
      return { count: state.count + 1 };

    case 'decrement':
      return { count: state.count - 1 };

    case 'reset':
      return initialState;

    default:
      return state;
  }
};


const Counter: React.FC = () => {
//5. usage of useReducer
    const [state, dispatch] = useReducer(reducer, initialState);

//6. UI Implementation
  return (
    <div>
      <h1>Count: {state.count}</h1>

      <button onClick={() => dispatch({ type: 'increment' })}>
        Increment
      </button>

      <button onClick={() => dispatch({ type: 'decrement' })}>
        Decrement
      </button>

      <button onClick={() => dispatch({ type: 'reset' })}>
        Reset
      </button>
    </div>
  );
};

export default Counter;