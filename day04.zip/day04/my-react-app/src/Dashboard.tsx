//Dashboard.tsx
import React, { useContext } from "react";
import { AuthContext } from "./AuthContext";

const Dashboard: React.FC = () => {
  const auth = useContext(AuthContext);

  if (!auth) throw new Error("Must be used inside AuthProvider");

  const { user, logout } = auth;

  return (
    <div>
      <h1>Welcome {user?.username}</h1>
      <button onClick={logout}>Logout</button>
    </div>
  );
};

export default Dashboard;
