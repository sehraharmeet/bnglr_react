// store.tsx
import { configureStore } from "@reduxjs/toolkit";
import movieReducer from "./movieSlice";
//first change
import createSagaMiddleware from "redux-saga";
import {watchMovieSaga} from './movieSaga';

// import userReducer from "./userSlice";
//2nd change
const sagaMiddleware=createSagaMiddleware();

export const store = configureStore({
  reducer: {
    movies: movieReducer,
    // user: userReducer,
  },
  //3rd change
  middleware:(getDefaultMiddleware)=>getDefaultMiddleware({thunk:false}).concat(sagaMiddleware)
});

//4th Chnage
sagaMiddleware.run(watchMovieSaga);

// Types for TS
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;