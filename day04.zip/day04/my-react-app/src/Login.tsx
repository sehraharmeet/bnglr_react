//Login.tsx
import React, { useState, useContext } from "react";
import { AuthContext } from "./AuthContext";

const Login: React.FC = () => {
  const auth = useContext(AuthContext);

  if (!auth) throw new Error("Must be used inside AuthProvider");

  const { login } = auth;

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    const success = login(username, password);
    if (!success) {
      alert("Invalid Credentials");
    }
  };

  return (
    <div>
      <h2>Login</h2>

      <input
        placeholder="Username"
        onChange={(e) => setUsername(e.target.value)}
      />

      <input
        type="password"
        placeholder="Password"
        onChange={(e) => setPassword(e.target.value)}
      />

      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default Login;
