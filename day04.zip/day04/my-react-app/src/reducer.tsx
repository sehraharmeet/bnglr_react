import { BUY, SELL, RESET, FLUCTUATE, Action } from './actionTypes';

// State Type
export type State = {
  stockPrice: number;
  quantity: number;
  totalInvestment: number;
};

// Initial State
export const initialState: State = {
  stockPrice: 100,
  quantity: 0,
  totalInvestment: 0,
};

// Reducer Function
export const stockReducer = (state: State, action: Action): State => {
  switch (action.type) {
    case BUY:
      return {
        ...state,
        quantity: state.quantity + 1,
        totalInvestment: state.totalInvestment + state.stockPrice,
      };

    case SELL:
      if (state.quantity === 0) return state;
      return {
        ...state,
        quantity: state.quantity - 1,
        totalInvestment: state.totalInvestment - state.stockPrice,
      };

    case RESET:
      return initialState;

    case FLUCTUATE:
      return {
        ...state,
        stockPrice: Math.max(0, state.stockPrice + action.payload),
      };

    default:
      return state;
  }
};
