// MovieList.tsx
import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "./store";
import { voteMovieRequest } from "./movieSlice";

const MovieList: React.FC = () => {
  const movies = useSelector((state: RootState) => state.movies.movies);
  const dispatch = useDispatch<AppDispatch>();

  return (
    <div>
      <h2>Movie Voting App</h2>

      {movies.map(movie => (
        <div key={movie.id} style={{ border: "1px solid #ccc", padding: "10px", margin: "10px" }}>
          <h3>{movie.title}</h3>
          <p>Genre: {movie.genre}</p>
          <p>Votes: {movie.votes}</p>

          <button onClick={() => dispatch(voteMovieRequest(movie.id))}>
            Vote 
          </button>
        </div>
      ))}
    </div>
  );
};

export default MovieList;
