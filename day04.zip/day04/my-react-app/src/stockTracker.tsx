// import React, { useState } from 'react';

// const StockTracker: React.FC = () => {
//   const [stockPrice, setStockPrice] = useState<number>(100);

//   const increasePrice = (): void => {
//     setStockPrice(prevPrice => prevPrice + 10);
//   };

//   const decreasePrice = (): void => {
//     setStockPrice(prevPrice => (prevPrice > 0 ? prevPrice - 10 : 0));
//   };

//   return (
//     <div>
//       <h1>Stock Price: {stockPrice}</h1>
//       <button onClick={increasePrice}>Buy (+ 10)</button>
//       <button onClick={decreasePrice}>Sell (- 10)</button>
//     </div>
//   );
// };

// export default StockTracker;

import React, { useState, useEffect } from 'react';

const StockTracker: React.FC = () => {
  const [stockPrice, setStockPrice] = useState<number>(100);
  const [quantity, setQuantity] = useState<number>(0);
  const [totalInvestment, setTotalInvestment] = useState<number>(0);

  const buyStock = (): void => {
    setQuantity(prev => prev + 1);
    setTotalInvestment(prev => prev + stockPrice);
  };

  const sellStock = (): void => {
    if (quantity > 0) {
      setQuantity(prev => prev - 1);
      setTotalInvestment(prev => prev - stockPrice);
    }
  };

  const reset = (): void => {
    setStockPrice(100);
    setQuantity(0);
    setTotalInvestment(0);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      const randomChange = Math.floor(Math.random() * 21) - 10;  
      setStockPrice(prev => Math.max(0, prev + randomChange));
    }, 3000);

    return () => clearInterval(interval); // cleanup
  }, []);

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Stock Tracker</h1>

      <h2>Stock Price: {stockPrice}</h2>
      <h3>Quantity Owned: {quantity}</h3>
      <h3>Total Investment: {totalInvestment}</h3>

      <button onClick={buyStock}>Buy</button>
      <button onClick={sellStock} disabled={quantity === 0}>
        Sell
      </button>
      <button onClick={reset}>Reset</button>
    </div>
  );
};

export default StockTracker;