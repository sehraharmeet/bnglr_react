import React, { useState } from 'react';

const StockExample: React.FC = () => {
 const [stockPrice, setStockPrice] = useState<number>(100);

 const increasePrice = (): void => {
  setStockPrice(prevPrice => prevPrice + 10);
 };

 const decreasePrice = (): void => {
  setStockPrice(prevPrice => (prevPrice > 0 ? prevPrice - 10 : 0));
 };

 return (
  <div>
   <h1>Stock Price: {stockPrice}</h1>
   <button onClick={increasePrice}>Buy (+ 10)</button>
   <button onClick={decreasePrice}>Sell (- 10)</button>
  </div>
 );
};

export default StockExample;
