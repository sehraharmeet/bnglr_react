// import React, { useState, useEffect } from 'react';

// // Define type for API response
// interface Post {
//   userId: number;
//   id: number;
//   title: string;
//   body: string;
// }

// const FetchDataWithPromise: React.FC = () => {
//   const [data, setData] = useState<Post | null>(null);
//   const [error, setError] = useState<string | null>(null);

//   useEffect(() => {
//     fetch('https://jsonplaceholder.typicode.com/posts/1')
//       .then((response) => {
//         if (!response.ok) {
//           throw new Error('Network response was not ok');
//         }
//         return response.json();
//       })
//       .then((data: Post) => {
//         setData(data);
//       })
//       .catch((err: Error) => {
//         setError('Failed to fetch data');
//       });
//   }, []);

//   if (error) return <div>{error}</div>;
//   if (!data) return <div>Loading...</div>;

//   return (
//     <div>
//       <h3>{data.title}</h3>
//       <p>{data.body}</p>
//     </div>
//   );
// };

// export default FetchDataWithPromise;


import React, { useState, useEffect } from 'react';

// Define API response type
interface Post {
  userId: number;
  id: number;
  title: string;
  body: string;
}

const FetchDataWithAsync: React.FC = () => {
  const [data, setData] = useState<Post | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts/1');

        if (!response.ok) {
          throw new Error('Network response was not ok');
        }

        const result: Post = await response.json();
        setData(result);

      } catch (err) {
        setError('Failed to fetch data');
      }
    };

    fetchData();
  }, []);

  if (error) return <div>{error}</div>;
  if (!data) return <div>Loading...</div>;

  return (
    <div>
      <h3>{data.title}</h3>
      <p>{data.body}</p>
    </div>
  );
};

export default FetchDataWithAsync;
