// MyComponent.tsx
import React, { useContext, useState } from "react";
import { MyContext } from "./MyContext";

const MyComponent: React.FC = () => {
    // const [txt,setText]=useState(0);
 const { text,setText} = useContext(MyContext);
 return (
  <div>
    Child Component:
   <h1>{text}</h1>
   <button onClick={()=>setText("Updation from Child")}>Change From Child</button>
  </div>
 );
};
export default MyComponent;

