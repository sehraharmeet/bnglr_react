import React, { useState } from 'react';
import Book from './Book';

// 1. Define Book type
export type BookType = {
  id: number;
  title: string;
  votes: number;
};

const BookVoting: React.FC = () => {
  const [books, setBooks] = useState<BookType[]>([
    { id: 1, title: 'Harry Potter', votes: 0 },
    { id: 2, title: 'Lord of the Rings', votes: 0 },
    { id: 3, title: 'The Hobbit', votes: 0 },
  ]);

  // 2. Typed function
  const handleVote = (bookId: number): void => {
    console.log(bookId);
    setBooks((prevBooks) =>
      prevBooks.map((book) =>
        book.id === bookId
          ? { ...book, votes: book.votes + 1 }
          : book
      )
    );
  };

    const resetVotes=():void=>{
      setBooks(prev=>prev.map(book=>({...book,votes:0})))
    };
  return (
    <div>
      <h1>Vote for Your Favorite Book</h1>

      {books.map((book) => (
        <Book key={book.id} BK={book} onVote={handleVote} />
      ))}
      <button onClick={resetVotes}>Reset All Votes</button>
    </div>
  );
};

export default BookVoting;