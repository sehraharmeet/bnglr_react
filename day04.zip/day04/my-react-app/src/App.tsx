//App.tsx
import React, { useContext, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import StockTracker from './stockTracker';
import StockTracker2 from './stockTracker2';
import Counter from './counter';
import StockExample from './StockExample';
import StockTrackerMain from './StockTrrackerMain';
import BookVoting from './BookVoting';
import MyComponent from './MyComponent';
import { MyContext } from './MyContext';
import MyComponent2 from './MyComponent2';
import Login from './Login';
import Dashboard from './Dashboard';
import { AuthContext, AuthProvider } from './AuthContext';
import MovieList from './movieList';
import FetchDataWithPromise from './picData';

// const AppContent: React.FC = () => {
//   const auth = useContext(AuthContext);
//   if (!auth) throw new Error("Must be used inside AuthProvider");
//     const { user } = auth;
//   return user ? <Dashboard /> : <Login />;
// };

function App() {
  // const [text,setText]=useState<string>("Harmeet from Main App");
  return (
    <div className="App">
       {/* <Counter />
       <StockExample /> 
       <StockTrackerMain /> */}
       {/* <BookVoting  /> */}
       {/* Parent Component
       <MyContext.Provider value={{text,setText}}>
          <MyComponent />
          <MyComponent2 />
       </MyContext.Provider> */}
      {/* <AuthProvider>
      <AppContent />
    </AuthProvider> */}
    {/* <MovieList /> */}
    <FetchDataWithPromise />

    </div>
  );
}

export default App;
