// Action constants
export const BUY = 'BUY';
export const SELL = 'SELL';
export const RESET = 'RESET';
export const FLUCTUATE = 'FLUCTUATE';

// Action type definition (TypeScript)
export type Action =
  | { type: typeof BUY }
  | { type: typeof SELL }
  | { type: typeof RESET }
  | { type: typeof FLUCTUATE; payload: number };