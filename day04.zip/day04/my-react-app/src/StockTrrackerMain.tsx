import React, { useReducer, useEffect } from 'react';
import { stockReducer, initialState } from './reducer';
import { BUY, SELL, RESET, FLUCTUATE } from './actionTypes';

const StockTrackerMain: React.FC = () => {
  const [state, dispatch] = useReducer(stockReducer, initialState);

  useEffect(() => {
    const interval = setInterval(() => {
      const randomChange = Math.floor(Math.random() * 21) - 10;
      dispatch({ type: FLUCTUATE, payload: randomChange });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Stock Tracker (Modular useReducer)</h1>

      <h2>Stock Price: ₹{state.stockPrice}</h2>
      <h3>Quantity: {state.quantity}</h3>
      <h3>Total Investment: ₹{state.totalInvestment}</h3>

      <button onClick={() => dispatch({ type: BUY })}>Buy</button>
      <button onClick={() => dispatch({ type: SELL })}>Sell</button>
      <button onClick={() => dispatch({ type: RESET })}>Reset</button>
    </div>
  );
};

export default StockTrackerMain;
