// movieSlice.tsx
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { initialState } from "./initialState";

const movieSlice = createSlice({
  name: "movies",
  initialState,
  reducers: {
    // voteMovie: (state, action: PayloadAction<number>) => {
    //   const movie = state.movies.find(m => m.id == action.payload);
    //   if (movie) {
    //     movie.votes += 1;
    //   }
    // }
    voteMovieRequest: (state, action: PayloadAction<number>) => {
      // Saga will handle this
    },
    voteMovieSuccess: (state, action: PayloadAction<number>) => {
      const movie = state.movies.find(m => m.id === action.payload);
      if (movie) {
        movie.votes += 1;
      }
    }
  }
});

export const { voteMovieRequest,voteMovieSuccess } = movieSlice.actions;
export default movieSlice.reducer;
