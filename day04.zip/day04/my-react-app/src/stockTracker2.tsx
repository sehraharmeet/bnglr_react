import React, { useReducer, useEffect } from 'react';

// 1. Define State Type
type State = {
  stockPrice: number;
  quantity: number;
  totalInvestment: number;
};

// 2. Define Action Types
type Action =
  | { type: 'BUY' }
  | { type: 'SELL' }
  | { type: 'RESET' }
  | { type: 'FLUCTUATE'; payload: number };

// 3. Initial State
const initialState: State = {
  stockPrice: 100,
  quantity: 0,
  totalInvestment: 0,
};

// 4. Reducer Function
const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case 'BUY':
      return {
        ...state,
        quantity: state.quantity + 1,
        totalInvestment: state.totalInvestment + state.stockPrice,
      };

    case 'SELL':
      if (state.quantity === 0) return state;
      return {
        ...state,
        quantity: state.quantity - 1,
        totalInvestment: state.totalInvestment - state.stockPrice,
      };

    case 'RESET':
      return initialState;

    case 'FLUCTUATE':
      return {
        ...state,
        stockPrice: Math.max(0, state.stockPrice + action.payload),
      };

    default:
      return state;
  }
};

// 5. Component
const StockTracker2: React.FC = () => {
  const [state, dispatch] = useReducer(reducer, initialState);

  // Market fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      const randomChange = Math.floor(Math.random() * 21) - 10;
      dispatch({ type: 'FLUCTUATE', payload: randomChange });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Stock Tracker Implementation of useReducer</h1>

      <h2>Stock Price: ₹{state.stockPrice}</h2>
      <h3>Quantity: {state.quantity}</h3>
      <h3>Total Investment: ₹{state.totalInvestment}</h3>

      <button onClick={() => dispatch({ type: 'BUY' })}>Buy</button>
      <button onClick={() => dispatch({ type: 'SELL' })}>
        Sell
      </button>
      <button onClick={() => dispatch({ type: 'RESET' })}>
        Reset
      </button>
    </div>
  );
};

export default StockTracker2;