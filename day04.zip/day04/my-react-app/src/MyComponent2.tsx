// // MyComponent2.tsx
// import React, { useContext, useState } from "react";
// import { MyContext } from "./MyContext";

// const MyComponent2: React.FC = () => {
//     // const [txt,setText]=useState(0);
//  const { text,setText} = useContext(MyContext);
//  return (
//   <div>
//     Another Child Component:
//    <h1>{text}</h1>
    
//   </div>
//  );
// };
// export default MyComponent2;




import React, { useContext, useState } from "react";
import { MyContext } from "./MyContext";

const MyComponent2: React.FC = () => {
 const { text, setText } = useContext(MyContext);

 // Local state to hold input value
 const [inputValue, setInputValue] = useState<string>("");

 return (
  <div>
   <h1>Current Value: {text}</h1>

   <input
    type="text"
    value={inputValue}
    onChange={(e) => setInputValue(e.target.value)}
    maxLength={10}  
    placeholder="Type Here"
    />

   <button onClick={() => setText(inputValue)}>
    Update Context
   </button>
  </div>
 );
};

export default MyComponent2;

