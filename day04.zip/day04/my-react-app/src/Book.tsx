import React from 'react';
import { BookType } from './BookVoting';

type Props = {
  BK: BookType;
  onVote: (id: number) => void;
};

const Book: React.FC<Props> = ({ BK, onVote }) => {
  return (
    <div>
      <h3>{BK.title}</h3>
      <p>Votes: {BK.votes}</p>
      <button onClick={() => onVote(BK.id)}>Vote</button>
    </div>
  );
};

export default Book;