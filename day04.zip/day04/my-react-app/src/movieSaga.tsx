// movieSaga.tsx
import { takeEvery, put, delay } from "redux-saga/effects";
import { voteMovieRequest, voteMovieSuccess } from "./movieSlice";

// Worker Saga
function* handleVote(action: ReturnType<typeof voteMovieRequest>) {
  try {
    // simulate API delay
    yield delay(5000);

    // dispatch success
    yield put(voteMovieSuccess(action.payload));
  } catch (error) {
    console.error("Voting failed", error);
  }
}

// Watcher Saga
export function* watchMovieSaga() {
  yield takeEvery(voteMovieRequest.type, handleVote);
}
