import React from 'react';
import logo from './logo.svg';
import './App.css';
import { UserComponent } from './userComponent';
import { AddUserComponent } from './addUserConponent';

function App() {
  return (
    <div className="App">
      {/* <UserComponent /> */}
      <AddUserComponent />
    </div>
  );
}

export default App;
