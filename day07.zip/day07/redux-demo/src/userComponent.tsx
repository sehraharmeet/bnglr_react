import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsers } from "./fetchUsers";
import { RootState, AppDispatch } from "./store";

export const UserComponent = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { users, loading } = useSelector((state: RootState) => state.users);

  useEffect(() => {
    dispatch(fetchUsers());
  }, [dispatch]);

  return (
    <div>
      <h2>Users</h2>
      {loading ? "Loading..." : users.map(u => <p key={u.id}>{u.name}</p>)}
    </div>
  );
};