// import { AppDispatch } from "./store";
// import { fetchStart, fetchSuccess, fetchFailure } from "./userSlicer";

// export const fetchUsers = () => async (dispatch: AppDispatch) => {
//   dispatch(fetchStart());

//   try {
//     const res = await fetch("https://jsonplaceholder.typicode.com/users");
//     const data = await res.json();

//     dispatch(fetchSuccess(data));
//   } catch {
//     dispatch(fetchFailure("Error"));
//   }
// };

import { AppDispatch } from "./store";
import { fetchStart, fetchSuccess, fetchFailure } from "./userSlicer";

export const fetchUsers = () => (dispatch: AppDispatch) => {

  dispatch(fetchStart());

  fetch("https://jsonplaceholder.typicode.com/users")
    .then((res) => {
      return res.json();
    })
    .then((data) => {
      dispatch(fetchSuccess(data));
    })
    .catch((error) => {
      dispatch(fetchFailure("Error"));
    });
};