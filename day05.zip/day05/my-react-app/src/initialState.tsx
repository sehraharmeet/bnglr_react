// initialState.tsx
import { MovieState } from "./types";

export const initialState: MovieState = {
  movies: [
    { id: 1, title: "RRR", genre: "Action", votes: 0 },
    { id: 2, title: "Bahubali", genre: "ActionEpic", votes: 0 },
    { id: 3, title: "Dhurandhar", genre: "Action", votes: 0 }
  ]
};
