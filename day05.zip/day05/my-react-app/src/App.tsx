import React from 'react';
import logo from './logo.svg';
import './App.css';
import MovieList from './MovieList';

// import MovieList2 from './Ex2_MovieList';

function App() {
  return (
    <div className="App">
     {/* <MovieList2 /> */}
     <MovieList />
    </div>
  );
}

export default App;
