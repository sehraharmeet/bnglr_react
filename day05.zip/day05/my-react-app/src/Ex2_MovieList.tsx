import React from "react";
import { Provider, useDispatch, useSelector } from "react-redux";
import { store, voteMovie, RootState } from "./Ex2_SliceStore";

const MovieList2 = () => {
  const movies = useSelector((state: RootState) => state.movies.movies);
  const dispatch = useDispatch();

  return (
    <div>
      <h2>Movie Voting</h2>
      {movies.map(m => (
        <div key={m.id}>
          <h3>{m.title}</h3>
          <p>{m.genre}</p>
          <p>Votes: {m.votes}</p>
          <button onClick={() => dispatch(voteMovie(m.id))}>
            Vote
          </button>
        </div>
      ))}
    </div>
  );
};
export default MovieList2;
 