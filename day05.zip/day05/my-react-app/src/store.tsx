// // store.tsx
// import { configureStore } from "@reduxjs/toolkit";
// import movieReducer from "./movieSlice";

// export const store = configureStore({
//   reducer: {
//     movies: movieReducer
//   }
// });

// // Types for TS
// export type RootState = ReturnType<typeof store.getState>;
// export type AppDispatch = typeof store.dispatch;


// store.tsx
import { configureStore } from "@reduxjs/toolkit";
import createSagaMiddleware from "redux-saga";
import movieReducer from "./movieSlice";
import { watchMovieSaga } from "./movieSaga";

const sagaMiddleware = createSagaMiddleware();

export const store = configureStore({
  reducer: {
    movies: movieReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({ thunk: false }).concat(sagaMiddleware)
});

// run saga
sagaMiddleware.run(watchMovieSaga);

// types
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
