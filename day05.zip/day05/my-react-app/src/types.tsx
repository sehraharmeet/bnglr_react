// types.tsx
export interface Movie {
  id: number;
  title: string;
  genre: string;
  votes: number;
}

export interface MovieState {
  movies: Movie[];
}
