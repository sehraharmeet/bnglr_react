// store.ts
import { configureStore, createSlice, PayloadAction } from "@reduxjs/toolkit";

// Types
interface Movie {
  id: number;
  title: string;
  genre: string;
  votes: number;
}

// Initial State
const initialState = {
  movies: [
    { id: 1, title: "Inception", genre: "Sci-Fi", votes: 0 },
    { id: 2, title: "Titanic", genre: "Romance", votes: 0 }
  ]
};

// Slice
const movieSlice = createSlice({
    
  name: "movies",
  initialState,
  reducers: {
    voteMovie: (state, action: PayloadAction<number>) => {
      const movie = state.movies.find(m => m.id === action.payload);
      if (movie) movie.votes++;
    }
  }
});

export const { voteMovie } = movieSlice.actions;

// Store
export const store = configureStore({
  reducer: {
    movies: movieSlice.reducer
  }
});

// Types
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;