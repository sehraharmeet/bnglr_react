from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
@app.route('/')
def home():
    return "Welcome to the Flask REST API!"

@app.route('/harmeet', methods=['GET'])
def get_data():
    data = {
        'message': 'This is demo response being create by Me.... :-)',
        'status': 'success'
    }
    return jsonify(data)

@app.route('/Bosch', methods=['GET'])
def get_data2():
    data = "Thanks"
    return (data)

app.run(port=5000)

