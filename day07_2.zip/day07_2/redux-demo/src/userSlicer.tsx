import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface User {
  id: number;
  name: string;
}

interface UserState {
  users: User[];
  loading: boolean;
  error: string;
}

const initialState: UserState = {
  users: [],
  loading: false,
  error: ""
};

const userSlice = createSlice({
  name: "users",
  initialState,
  reducers: {
    fetchStart(state) {
        console.log("Reducer:fetchStart");
      state.loading = true;
    },
    fetchSuccess(state, action: PayloadAction<User[]>) {
        console.log("Reducer:fetchSuccess");
      state.loading = false;
      state.users = action.payload;
    },
    fetchFailure(state, action: PayloadAction<string>) {
        console.log("Reducer:fetchFailure");
      state.loading = false;
      state.error = action.payload;
    }
  }
});

export const { fetchStart, fetchSuccess, fetchFailure } = userSlice.actions;
export default userSlice.reducer;