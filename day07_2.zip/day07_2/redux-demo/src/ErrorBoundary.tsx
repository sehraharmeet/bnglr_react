import React, { Component, ReactNode } from "react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    console.log("ErrorBoundary caught error:", error);
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.log("Error Info:", info);
  }

  render() {
    if (this.state.hasError) {
      return <h2>Something went wrong!Please Try Later </h2>;
    }

    return this.props.children;
  }
}

export default ErrorBoundary;