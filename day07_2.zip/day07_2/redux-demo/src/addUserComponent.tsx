import { useState } from "react";
import { fetchUsers } from "./fetchUsers";
import { useDispatch } from "react-redux";
import { AppDispatch } from "./store";
import "./styles/style.scss";

export const AddUserComponent = () => {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
    const dispatch=useDispatch<AppDispatch>();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    console.log("Sending data to API...", name);

    fetch("http://localhost:5000/addUser", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        name: name
      })
    })
      .then((res) => res.text())
      .then((data) => {
        console.log("Response from server:", data);
        setMessage(data);
        setName(""); // clear input
        dispatch(fetchUsers());
      })
      .catch((err) => {
        console.log("Error:", err);
      });
      
  };

  return (
    <div className="container">
      <h2>Add User</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <button type="submit">Add</button>
      </form>

      {message && <p>{message}</p>}
    </div>
 
  );
};