import React from 'react';
import logo from './logo.svg';
import './App.css';
import { UserComponent } from './userComponent';
import ErrorBoundary from './ErrorBoundary';
import { AddUserComponent } from './addUserComponent';
import HarmeetAPI from './HarmeetAPI';

function App() {
  return (
    <div className="App">
      {/* <ErrorBoundary>
     <UserComponent />
     <AddUserComponent />
     </ErrorBoundary> */}
     <HarmeetAPI />
    </div>
  );
}

export default App;
