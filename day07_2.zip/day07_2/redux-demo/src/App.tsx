import React from 'react';
import logo from './logo.svg';
import './App.css';
import { UserComponent } from './userComponent';
import ErrorBoundary from './ErrorBoundary';

function App() {
  return (
    <div className="App">
      <ErrorBoundary>
     <UserComponent />
     </ErrorBoundary>
    </div>
  );
}

export default App;
