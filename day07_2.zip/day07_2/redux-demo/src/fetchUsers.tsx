// import { AppDispatch } from "./store";
// import { fetchStart, fetchSuccess, fetchFailure } from "./userSlicer";

// export const fetchUsers = () => async (dispatch: AppDispatch) => {
//   dispatch(fetchStart());

//   try {
//     const res = await fetch("https://jsonplaceholder.typicode.com/users");
//     const data = await res.json();

//     dispatch(fetchSuccess(data));
//   } catch {
//     dispatch(fetchFailure("Error"));
//   }
// };

import { AppDispatch } from "./store";
import { fetchStart, fetchSuccess, fetchFailure } from "./userSlicer";

export const fetchUsers = () => (dispatch: AppDispatch) => {
console.log("API call is about to happen");
  dispatch(fetchStart());
console.log("Fetch Start Dispatched...");
  fetch("http://localhost:5000/users")
    .then((res) => {
      return res.json();
    })
    .then((data) => {
        console.log("recieved data successfully");
      dispatch(fetchSuccess(data));
      console.log("fetchsucces dispaltched");
    })
    .catch((error) => {
        console.log("Errorbefore failure dispatch");
      dispatch(fetchFailure("Error"));
    });
};