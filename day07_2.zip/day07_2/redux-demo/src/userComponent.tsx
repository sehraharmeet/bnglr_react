import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsers } from "./fetchUsers";
import { RootState, AppDispatch } from "./store";

export const UserComponent = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { users, loading } = useSelector((state: RootState) => state.users);
  console.log("Component Rendered...",{users,loading});

  useEffect(() => {
    console.log("Component Mounted");
    dispatch(fetchUsers());
    console.log("Dispatch fethUsers Called...");
  }, [dispatch]);

//   console.log(users.length);
if (users.length <= 0) {
    throw new Error("Test Crash!");
  }
  
  return (
    <div>
      <h2>Users</h2>
      {loading ? "Loading..." : users.map(u => <p key={u.id}>{u.id}-{u.name}</p>)}
    </div>
  );
};