const express=require("express");
const cors=require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/harmeet",(req, res) => {
  const name=req.query.name;
  // const no=req.params.id;
  res.send("This is Harmeet calling from Browser...for "  + name);
});

app.get("/users", (req, res) => {
  console.log("API called from React");

  res.json([
    { id: 1, name: "Harmeet" },
    { id: 2, name: "Reema" },
    { id: 3, name: "Saara" }
  ]);
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});