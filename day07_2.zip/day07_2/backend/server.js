const express=require("express");
const cors=require("cors");

const app = express();

app.use(cors());
app.use(express.json());

//In-Memory
let users=[
    { id: 1, name: "Harmeet" },
    { id: 2, name: "Reema" },
    { id: 3, name: "Saara" }
  ];

app.get("/harmeet",(req, res) => {
  const name=req.query.name;//localhost:5000/harmeet?name=Bosch
  // const no=req.params.id;//localhost:5000/harmeet/101
  res.send("This is Harmeet calling from Browser...for "  + name);
});

app.post("/addUser",(req,res)=>{
  const newUser=req.body;
  const user={
    id:users.length+1,
    name:newUser.name//to pick name textbox values from newUser BODY
  };
  users.push(user);//to add new user entry to users json
  console.log(newUser);
  res.send("User Added...");
});
app.get("/users", (req, res) => {
  console.log("API called from React");

  res.json(users);
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});